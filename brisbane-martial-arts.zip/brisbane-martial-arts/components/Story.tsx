import Link from "next/link";

export default function Story() {
  return (
    <section className="relative py-24 lg:py-40 bg-ink-950 overflow-hidden">
      {/* Decorative oversized number */}
      <div
        aria-hidden
        className="absolute top-0 right-0 h-display text-bone/[0.025] text-[40vw] leading-[0.75] select-none pointer-events-none"
      >
        20
      </div>

      <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 lg:gap-16">
          {/* Left: tag + heading */}
          <div className="lg:col-span-5 reveal">
            <div className="sticky top-32">
              <div className="flex items-center gap-3 text-ember text-xs uppercase tracking-[0.3em] mb-6">
                <span className="w-8 h-px bg-ember" />
                <span>Why BTC</span>
              </div>
              <h2 className="h-display text-bone text-5xl md:text-6xl lg:text-7xl">
                Built different.
                <br />
                <span className="h-serif text-bone/50 italic text-[0.7em]">
                  on purpose.
                </span>
              </h2>
            </div>
          </div>

          {/* Right: editorial content */}
          <div className="lg:col-span-7 lg:col-start-7 space-y-12 reveal">
            <p className="text-bone/85 text-2xl lg:text-3xl leading-relaxed font-light">
              Most martial arts gyms compromise. Shared halls, rented mats, one
              instructor stretched too thin. We built BTC the other way around —
              <span className="text-ember"> four dedicated halls, permanent kit,
              specialist coaches in every discipline.</span>
            </p>

            <div className="grid sm:grid-cols-2 gap-px bg-bone/10 border border-bone/10">
              {[
                {
                  title: "Four halls, no waiting",
                  body: "Every hall is fully matted, air-conditioned, and dedicated to the discipline trained in it.",
                },
                {
                  title: "Specialist coaches",
                  body: "Including Australasia's most senior Krav Maga instructor and one of QLD's top TKD masters.",
                },
                {
                  title: "Onsite gym & shop",
                  body: "Train fitness before or after class. Pick up gear without ordering and waiting on a delivery.",
                },
                {
                  title: "All ages, all levels",
                  body: "Members aged 3 to 75. Beginners-streams across every program. Nobody trains in over their head.",
                },
              ].map((item) => (
                <div key={item.title} className="bg-ink-950 p-6 lg:p-8">
                  <div className="text-ember mb-3">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 2 L22 12 L12 22 L2 12 Z" />
                    </svg>
                  </div>
                  <h3 className="text-bone text-base font-semibold mb-2">{item.title}</h3>
                  <p className="text-bone/60 text-sm leading-relaxed">{item.body}</p>
                </div>
              ))}
            </div>

            <Link
              href="/about"
              className="inline-flex items-center gap-2 text-bone hover:text-ember transition-colors text-sm uppercase tracking-[0.15em] font-medium link-underline"
            >
              Read the BTC story
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M13 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
