import Link from "next/link";
import { disciplines } from "@/lib/data";
import { Icon, type IconName } from "./Icons";

const iconMap: Record<string, IconName> = {
  taekwondo: "zap",
  bjj: "shield",
  kravmaga: "flame",
  pilates: "leaf",
};

export default function DisciplineGrid() {
  return (
    <section id="disciplines" className="relative py-24 lg:py-32 bg-ink-900">
      <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
        {/* Section header */}
        <div className="grid lg:grid-cols-12 gap-8 mb-16 items-end">
          <div className="lg:col-span-7 reveal">
            <div className="flex items-center gap-3 text-ember text-xs uppercase tracking-[0.3em] mb-6">
              <span className="w-8 h-px bg-ember" />
              <span>Four disciplines, one academy</span>
            </div>
            <h2 className="h-display text-bone text-5xl md:text-6xl lg:text-7xl">
              Pick your <span className="h-serif text-ember italic">art.</span>
            </h2>
          </div>
          <div className="lg:col-span-4 lg:col-start-9 reveal">
            <p className="text-bone/60 text-base leading-relaxed">
              We don&apos;t pick favourites. Cross-train across all four, or go
              deep in the one that lights you up. Your membership covers
              everything we teach.
            </p>
          </div>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-2 gap-px bg-bone/10 border border-bone/10">
          {disciplines.map((d, i) => (
            <Link
              key={d.slug}
              href={`/classes#${d.slug}`}
              className="group relative bg-ink-900 hover:bg-ink-800 transition-all duration-500 p-8 lg:p-12 reveal overflow-hidden"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              {/* Big number watermark */}
              <div
                aria-hidden
                className="absolute top-8 right-8 h-display text-bone/[0.08] group-hover:text-ember/20 text-7xl lg:text-8xl transition-colors duration-500 tabular"
              >
                {d.number}
              </div>

              <div className="relative z-10">
                <div className="text-ember mb-6 transform group-hover:scale-110 group-hover:-translate-y-1 transition-transform duration-500">
                  <Icon name={iconMap[d.slug]} className="w-9 h-9" />
                </div>

                <h3 className="h-display text-bone text-4xl lg:text-5xl mb-2 group-hover:text-ember transition-colors">
                  {d.name}
                </h3>
                <div className="text-bone/40 text-xs uppercase tracking-[0.2em] mb-6">
                  Origin: {d.origin} · Ages {d.ages}
                </div>

                <p className="text-bone/70 text-sm leading-relaxed mb-8 max-w-md">
                  {d.description}
                </p>

                {/* Intensity meter */}
                <div className="flex items-center gap-3 mb-8">
                  <span className="text-bone/40 text-[10px] uppercase tracking-[0.2em]">Intensity</span>
                  <div className="flex gap-1.5">
                    {[1, 2, 3, 4, 5].map((n) => (
                      <span
                        key={n}
                        className={`block w-6 h-[3px] ${
                          n <= d.intensity ? "bg-ember" : "bg-bone/10"
                        }`}
                      />
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2 text-bone group-hover:text-ember transition-colors text-sm uppercase tracking-[0.15em] font-medium">
                  Explore the program
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    className="transform group-hover:translate-x-2 transition-transform"
                  >
                    <path d="M5 12h14M13 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
