"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import Logo from "./Logo";

const nav = [
  { href: "/classes", label: "Classes" },
  { href: "/timetable", label: "Timetable" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export default function Header() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 24);
    handler();
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-ink-900/85 backdrop-blur-xl border-b border-bone/10"
            : "bg-transparent"
        }`}
      >
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10 h-16 lg:h-20 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 group" aria-label="BTC Brisbane Martial Arts — home">
            <Logo className="h-9 lg:h-10 w-auto text-bone group-hover:text-ember transition-colors" />
          </Link>

          <nav className="hidden lg:flex items-center gap-1" aria-label="Primary">
            {nav.map((item) => {
              const active = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`px-4 py-2 text-[13px] uppercase tracking-[0.12em] font-medium transition-colors ${
                    active ? "text-ember" : "text-bone/70 hover:text-bone"
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-3">
            <a
              href="tel:+61731774550"
              className="hidden md:flex items-center gap-2 text-bone/80 hover:text-bone text-sm font-medium tabular"
              aria-label="Call BTC on 07 3177 4550"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
              </svg>
              <span>(07) 3177 4550</span>
            </a>
            <Link href="/contact" className="btn btn-primary hidden sm:inline-flex">
              <span>Free Trial</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M5 12h14M13 5l7 7-7 7" />
              </svg>
            </Link>
            <button
              onClick={() => setOpen(!open)}
              className="lg:hidden w-10 h-10 flex items-center justify-center text-bone"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
            >
              {open ? (
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 6L6 18M6 6l12 12" />
                </svg>
              ) : (
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 12h18M3 6h18M3 18h18" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <div
        className={`lg:hidden fixed inset-0 z-40 bg-ink-900 transition-all duration-500 ${
          open ? "opacity-100 visible" : "opacity-0 invisible"
        }`}
      >
        <div className="h-full flex flex-col justify-between p-6 pt-24">
          <nav className="flex flex-col gap-1" aria-label="Mobile">
            {nav.map((item, i) => {
              const active = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`h-display text-6xl py-2 transition-colors ${
                    active ? "text-ember" : "text-bone hover:text-ember"
                  }`}
                  style={{
                    transitionDelay: open ? `${i * 80}ms` : "0ms",
                    transform: open ? "translateY(0)" : "translateY(20px)",
                    opacity: open ? 1 : 0,
                    transition: `opacity 500ms ${i * 80}ms, transform 500ms ${i * 80}ms`,
                  }}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="space-y-4">
            <a href="tel:+61731774550" className="block text-bone text-lg tabular">
              (07) 3177 4550
            </a>
            <Link href="/contact" className="btn btn-primary w-full">
              Book Free Trial
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}
