import Link from "next/link";

export default function Hero() {
  return (
    <section className="relative min-h-screen pt-20 lg:pt-24 overflow-hidden bg-ink-900">
      {/* Atmospheric background */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden>
        {/* Radial glow */}
        <div
          className="absolute top-1/2 -right-1/4 w-[80%] aspect-square rounded-full opacity-30 blur-[120px]"
          style={{
            background: "radial-gradient(circle, #FF4D2E 0%, transparent 60%)",
          }}
        />
        {/* Diagonal slash */}
        <svg
          className="absolute right-0 top-0 h-full w-1/3 opacity-[0.08]"
          viewBox="0 0 200 800"
          preserveAspectRatio="none"
        >
          <path d="M0 0 L200 0 L200 800 L0 800 Z" fill="url(#slash-grad)" />
          <defs>
            <linearGradient id="slash-grad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#FF4D2E" />
              <stop offset="100%" stopColor="transparent" />
            </linearGradient>
          </defs>
        </svg>
        {/* Grid lines */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
              "linear-gradient(#F5F1E8 1px, transparent 1px), linear-gradient(90deg, #F5F1E8 1px, transparent 1px)",
            backgroundSize: "80px 80px",
          }}
        />
      </div>

      {/* Watermark word */}
      <div
        aria-hidden
        className="absolute bottom-0 left-0 right-0 h-display text-bone/[0.025] text-[24vw] leading-[0.8] whitespace-nowrap select-none -mb-12 lg:-mb-16 pointer-events-none"
      >
        BRISBANE
      </div>

      {/* Side label - desktop only */}
      <div
        aria-hidden
        className="hidden lg:flex absolute right-8 top-1/2 -translate-y-1/2 origin-center rotate-90 items-center gap-3 text-xs uppercase tracking-[0.4em] text-bone/40"
      >
        <span className="block w-12 h-px bg-bone/30" />
        EST. 2003 — Stafford, Brisbane
        <span className="block w-12 h-px bg-bone/30" />
      </div>

      {/* Content */}
      <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10 min-h-[calc(100vh-5rem)] flex flex-col justify-center pb-16 pt-12">
        <div className="max-w-[1100px]">
          <div className="flex items-center gap-3 text-ember text-xs uppercase tracking-[0.3em] mb-8 reveal">
            <span className="w-8 h-px bg-ember" />
            <span>Brisbane&apos;s Largest Martial Arts Centre</span>
          </div>

          <h1 className="h-display text-bone text-[clamp(3.5rem,11vw,11rem)] reveal">
            <span className="block">Forge</span>
            <span className="block pl-[10vw]">
              <span className="h-serif text-bone/60 italic font-normal text-[0.7em]">your</span>{" "}
              own
            </span>
            <span className="block text-ember">edge.</span>
          </h1>

          <div className="mt-10 lg:mt-14 grid lg:grid-cols-12 gap-8 items-end reveal">
            <p className="lg:col-span-5 text-bone/70 text-lg lg:text-xl leading-relaxed max-w-md">
              Four halls. Ninety-plus classes a week. Taekwondo, BJJ, Krav Maga
              and Pilates — taught by Brisbane&apos;s most experienced coaches,
              for everyone aged three to seventy-five.
            </p>

            <div className="lg:col-span-4 lg:col-start-9 flex flex-col sm:flex-row lg:flex-col gap-3">
              <Link href="/contact" className="btn btn-primary">
                Start with a free class
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M5 12h14M13 5l7 7-7 7" />
                </svg>
              </Link>
              <Link href="/timetable" className="btn btn-ghost">
                View this week&apos;s timetable
              </Link>
            </div>
          </div>
        </div>

        {/* Bottom mini-stats strip */}
        <div className="mt-16 lg:mt-24 grid grid-cols-2 lg:grid-cols-4 gap-px bg-bone/10 border border-bone/10 reveal">
          {[
            ["90+", "Classes / week"],
            ["4", "Training halls"],
            ["3—75", "Years of age"],
            ["20+", "Years coaching"],
          ].map(([value, label]) => (
            <div key={label} className="bg-ink-900 p-5 lg:p-6 group hover:bg-ink-800 transition-colors">
              <div className="h-display text-3xl lg:text-4xl text-bone group-hover:text-ember transition-colors tabular">
                {value}
              </div>
              <div className="text-bone/50 text-[11px] uppercase tracking-[0.15em] mt-1">
                {label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        aria-hidden
        className="absolute bottom-6 left-1/2 -translate-x-1/2 hidden lg:flex flex-col items-center gap-2 text-bone/40 text-xs uppercase tracking-[0.3em]"
      >
        <span>Scroll</span>
        <span className="w-px h-12 bg-gradient-to-b from-bone/40 to-transparent" />
      </div>
    </section>
  );
}
