"use client";

import { useState } from "react";
import { disciplines } from "@/lib/data";

export default function ContactForm() {
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitting(true);
    // No backend wired up — simulate, swap with real endpoint later
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 700);
  }

  if (submitted) {
    return (
      <div className="border border-ember bg-ember/5 p-10 lg:p-14 text-center">
        <div className="text-ember text-3xl mb-4">✦</div>
        <h3 className="h-display text-bone text-4xl mb-4">You&apos;re in.</h3>
        <p className="text-bone/70 text-base max-w-md mx-auto leading-relaxed">
          We&apos;ll be in touch within one business day to confirm your free trial
          class. In the meantime, feel free to give us a call on{" "}
          <a href="tel:+61731774550" className="text-ember link-underline">
            (07) 3177 4550
          </a>
          .
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-6">
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="First name" name="firstName" required />
        <Field label="Last name" name="lastName" required />
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="Email" name="email" type="email" required />
        <Field label="Phone" name="phone" type="tel" required />
      </div>

      <div>
        <label className="block text-bone/40 text-[10px] uppercase tracking-[0.25em] mb-3">
          Who is the trial for?
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {[
            "Myself",
            "My child",
            "Both",
            "A friend",
          ].map((opt) => (
            <label
              key={opt}
              className="cursor-pointer border border-bone/15 px-4 py-3 text-sm text-bone/80 has-[:checked]:bg-ember has-[:checked]:text-ink has-[:checked]:border-ember hover:border-bone/40 transition-colors text-center"
            >
              <input type="radio" name="forWho" value={opt} className="sr-only" />
              {opt}
            </label>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-bone/40 text-[10px] uppercase tracking-[0.25em] mb-3">
          Interested in
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {disciplines.map((d) => (
            <label
              key={d.slug}
              className="cursor-pointer border border-bone/15 px-4 py-3 text-sm text-bone/80 has-[:checked]:bg-ember has-[:checked]:text-ink has-[:checked]:border-ember hover:border-bone/40 transition-colors text-center"
            >
              <input type="checkbox" name="disciplines" value={d.slug} className="sr-only" />
              {d.short}
            </label>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-bone/40 text-[10px] uppercase tracking-[0.25em] mb-3">
          Anything we should know?
        </label>
        <textarea
          name="message"
          rows={4}
          className="w-full bg-ink-900 border border-bone/15 px-4 py-3 text-bone placeholder:text-bone/30 focus:border-ember focus:outline-none transition-colors resize-none"
          placeholder="Goals, preferred days, injuries to be aware of, etc."
        />
      </div>

      <button
        type="submit"
        disabled={submitting}
        className="btn btn-primary w-full disabled:opacity-50"
      >
        {submitting ? "Sending..." : "Book my free trial"}
        {!submitting && (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M5 12h14M13 5l7 7-7 7" />
          </svg>
        )}
      </button>
      <p className="text-bone/40 text-xs leading-relaxed">
        By submitting, you agree we can contact you about your enquiry. We never
        share your details.
      </p>
    </form>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="block text-bone/40 text-[10px] uppercase tracking-[0.25em] mb-2">
        {label}{required && <span className="text-ember"> *</span>}
      </label>
      <input
        type={type}
        name={name}
        required={required}
        className="w-full bg-ink-900 border border-bone/15 px-4 py-3 text-bone placeholder:text-bone/30 focus:border-ember focus:outline-none transition-colors"
      />
    </div>
  );
}
