export default function Logo({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 200 50"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="BTC Brisbane Martial Arts"
    >
      {/* Diamond mark */}
      <g transform="translate(0, 1)">
        <path
          d="M24 4 L44 24 L24 44 L4 24 Z"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
        />
        <path
          d="M24 14 L34 24 L24 34 L14 24 Z"
          fill="currentColor"
        />
      </g>

      {/* BTC text */}
      <text
        x="56"
        y="28"
        fontFamily="var(--font-display), Impact, sans-serif"
        fontSize="22"
        fill="currentColor"
        letterSpacing="2"
      >
        BTC
      </text>
      <text
        x="56"
        y="42"
        fontFamily="var(--font-sans), system-ui, sans-serif"
        fontSize="7"
        fill="currentColor"
        letterSpacing="3"
        opacity="0.6"
      >
        BRISBANE MARTIAL ARTS
      </text>
    </svg>
  );
}
