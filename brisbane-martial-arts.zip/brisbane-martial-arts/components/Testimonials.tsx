"use client";

import { useEffect, useState } from "react";
import { testimonials } from "@/lib/data";

export default function Testimonials() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const id = setInterval(() => {
      setActive((a) => (a + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(id);
  }, []);

  return (
    <section className="relative py-24 lg:py-32 bg-ink-900 border-y border-bone/10 overflow-hidden">
      {/* Background quote mark */}
      <div
        aria-hidden
        className="absolute -top-20 left-0 h-display text-ember/[0.08] text-[40rem] leading-none select-none pointer-events-none"
      >
        &ldquo;
      </div>

      <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-3 reveal">
            <div className="flex items-center gap-3 text-ember text-xs uppercase tracking-[0.3em] mb-6">
              <span className="w-8 h-px bg-ember" />
              <span>Members</span>
            </div>
            <h2 className="h-display text-bone text-4xl lg:text-5xl">
              Words from the mats.
            </h2>
            <div className="mt-8 flex gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActive(i)}
                  className={`h-1 transition-all ${
                    i === active ? "w-10 bg-ember" : "w-4 bg-bone/20"
                  }`}
                  aria-label={`Show testimonial ${i + 1}`}
                />
              ))}
            </div>
          </div>

          <div className="lg:col-span-9 lg:col-start-5 min-h-[280px] flex flex-col justify-center reveal">
            {testimonials.map((t, i) => (
              <div
                key={i}
                aria-hidden={i !== active}
                className={`transition-opacity duration-500 ${
                  i === active ? "opacity-100" : "opacity-0 absolute pointer-events-none"
                }`}
              >
                <blockquote className="h-serif text-bone text-3xl md:text-4xl lg:text-5xl leading-[1.15] tracking-tightest mb-8">
                  &ldquo;{t.quote}&rdquo;
                </blockquote>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full border-2 border-ember flex items-center justify-center h-display text-ember">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <div className="text-bone font-semibold text-sm">{t.name}</div>
                    <div className="text-bone/50 text-xs uppercase tracking-[0.15em]">{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
