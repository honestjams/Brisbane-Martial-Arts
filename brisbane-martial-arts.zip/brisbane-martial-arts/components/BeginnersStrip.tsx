import Link from "next/link";
import { sessions, days, disciplines } from "@/lib/data";

export default function BeginnersStrip() {
  // Pick 6 beginner-friendly sessions, balanced across disciplines
  const beginnerByDiscipline: typeof sessions = [];
  disciplines.forEach((d) => {
    const found = sessions.find(
      (s) => s.discipline === d.slug && s.beginnerFriendly && s.ageGroup === "adults"
    );
    if (found) beginnerByDiscipline.push(found);
  });
  const featured = [
    ...beginnerByDiscipline,
    ...sessions
      .filter((s) => s.beginnerFriendly && s.ageGroup === "adults")
      .filter((s) => !beginnerByDiscipline.find((x) => x.id === s.id))
      .slice(0, Math.max(0, 6 - beginnerByDiscipline.length)),
  ].slice(0, 6);

  const fmtTime = (t: string) => {
    const [h, m] = t.split(":");
    const hh = parseInt(h);
    const ampm = hh >= 12 ? "pm" : "am";
    const h12 = hh % 12 === 0 ? 12 : hh % 12;
    return `${h12}:${m}${ampm}`;
  };

  return (
    <section className="relative py-24 lg:py-32 bg-ink-950">
      <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-8 mb-12 items-end">
          <div className="lg:col-span-7 reveal">
            <div className="flex items-center gap-3 text-ember text-xs uppercase tracking-[0.3em] mb-6">
              <span className="w-8 h-px bg-ember" />
              <span>This week — beginner-friendly</span>
            </div>
            <h2 className="h-display text-bone text-5xl md:text-6xl lg:text-7xl">
              Try a class on us.
            </h2>
          </div>
          <div className="lg:col-span-4 lg:col-start-9 reveal">
            <p className="text-bone/60 text-base leading-relaxed">
              Hand-picked sessions ideal for first-timers. Just turn up — we&apos;ll
              walk you through everything when you arrive.
            </p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-bone/10 border border-bone/10 reveal">
          {featured.map((s) => {
            const d = disciplines.find((x) => x.slug === s.discipline)!;
            const day = days.find((x) => x.id === s.day)!;
            return (
              <Link
                key={s.id}
                href="/contact"
                className="group bg-ink-950 hover:bg-ink-900 transition-colors p-6 lg:p-8 flex flex-col gap-6"
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="text-ember text-[10px] uppercase tracking-[0.25em] font-medium mb-2">
                      {d.short} · Beginner welcome
                    </div>
                    <div className="h-display text-bone text-3xl">{d.name}</div>
                  </div>
                  <div className="text-right tabular">
                    <div className="text-bone/40 text-xs uppercase tracking-[0.15em]">{day.short}</div>
                    <div className="text-bone text-lg font-medium mt-1">{fmtTime(s.start)}</div>
                  </div>
                </div>

                <div className="mt-auto pt-4 border-t border-bone/10 flex items-center justify-between">
                  <span className="text-bone/50 text-xs uppercase tracking-[0.15em]">
                    Hall {s.hall}
                  </span>
                  <span className="flex items-center gap-2 text-bone group-hover:text-ember transition-colors text-sm font-medium">
                    Book free
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <path d="M5 12h14M13 5l7 7-7 7" />
                    </svg>
                  </span>
                </div>
              </Link>
            );
          })}
        </div>

        <div className="mt-10 flex justify-center reveal">
          <Link href="/timetable" className="btn btn-ghost">
            See the full timetable
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M5 12h14M13 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </div>
    </section>
  );
}
