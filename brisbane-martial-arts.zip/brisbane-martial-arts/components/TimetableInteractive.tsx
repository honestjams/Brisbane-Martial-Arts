"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  sessions,
  days,
  ageGroups,
  disciplines,
  type ClassSession,
  type Day,
  type AgeGroup,
} from "@/lib/data";

type DisciplineFilter = "all" | (typeof disciplines)[number]["slug"];
type AgeFilter = "all" | AgeGroup;
type LevelFilter = "all" | "beginner";

const fmtTime = (t: string) => {
  const [h, m] = t.split(":");
  const hh = parseInt(h);
  const ampm = hh >= 12 ? "pm" : "am";
  const h12 = hh % 12 === 0 ? 12 : hh % 12;
  return `${h12}:${m === "00" ? "00" : m}${ampm}`;
};

const disciplineLabel: Record<string, string> = {
  taekwondo: "TKD",
  bjj: "BJJ",
  kravmaga: "KRV",
  pilates: "PIL",
};

const ageLabel = (id: AgeGroup) => ageGroups.find((a) => a.id === id)?.label || id;

function timeToMinutes(time: string) {
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
}

export default function TimetableInteractive() {
  const [discipline, setDiscipline] = useState<DisciplineFilter>("all");
  const [age, setAge] = useState<AgeFilter>("all");
  const [level, setLevel] = useState<LevelFilter>("all");

  const filtered = useMemo(() => {
    return sessions.filter((s) => {
      if (discipline !== "all" && s.discipline !== discipline) return false;
      if (age !== "all" && s.ageGroup !== age) return false;
      if (level === "beginner" && !s.beginnerFriendly) return false;
      return true;
    });
  }, [discipline, age, level]);

  const sessionsByDay = useMemo(() => {
    const map: Record<Day, ClassSession[]> = {
      mon: [],
      tue: [],
      wed: [],
      thu: [],
      fri: [],
      sat: [],
    };
    filtered.forEach((s) => map[s.day].push(s));
    Object.values(map).forEach((arr) =>
      arr.sort((a, b) => timeToMinutes(a.start) - timeToMinutes(b.start))
    );
    return map;
  }, [filtered]);

  const totalCount = filtered.length;

  return (
    <div>
      {/* Filter bar */}
      <div className="bg-ink-950 border-y border-bone/10 sticky top-16 lg:top-20 z-30 backdrop-blur-xl bg-ink-950/85">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10 py-5 flex flex-wrap items-center gap-x-6 gap-y-4">
          <span className="text-bone/40 text-xs uppercase tracking-[0.2em]">
            Filter
          </span>

          <FilterGroup
            label="Discipline"
            value={discipline}
            onChange={(v) => setDiscipline(v as DisciplineFilter)}
            options={[
              { id: "all", label: "All" },
              ...disciplines.map((d) => ({ id: d.slug, label: d.short })),
            ]}
          />

          <FilterGroup
            label="Age"
            value={age}
            onChange={(v) => setAge(v as AgeFilter)}
            options={[
              { id: "all", label: "All ages" },
              ...ageGroups.map((a) => ({ id: a.id, label: a.label })),
            ]}
          />

          <FilterGroup
            label="Level"
            value={level}
            onChange={(v) => setLevel(v as LevelFilter)}
            options={[
              { id: "all", label: "All levels" },
              { id: "beginner", label: "Beginner-friendly" },
            ]}
          />

          <div className="ml-auto flex items-center gap-3">
            <span className="text-bone/60 text-sm tabular">
              <span className="text-bone font-semibold">{totalCount}</span>{" "}
              {totalCount === 1 ? "class" : "classes"}
            </span>
            {(discipline !== "all" || age !== "all" || level !== "all") && (
              <button
                onClick={() => {
                  setDiscipline("all");
                  setAge("all");
                  setLevel("all");
                }}
                className="text-ember text-xs uppercase tracking-[0.15em] hover:underline"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="mx-auto max-w-[1400px] px-5 lg:px-10 py-10 lg:py-16">
        {totalCount === 0 ? (
          <div className="text-center py-32">
            <div className="h-display text-bone/40 text-6xl mb-4">No classes</div>
            <p className="text-bone/60">Try widening your filters above.</p>
          </div>
        ) : (
          <div className="grid lg:grid-cols-6 gap-px bg-bone/10 border border-bone/10">
            {days.map((day) => {
              const dayClasses = sessionsByDay[day.id];
              return (
                <div key={day.id} className="bg-ink-900 min-h-[200px]">
                  <div className="px-5 py-4 border-b border-bone/10 bg-ink-950 sticky top-32 lg:top-36 z-20">
                    <div className="h-display text-bone text-xl">{day.name}</div>
                    <div className="text-bone/40 text-[10px] uppercase tracking-[0.2em] tabular">
                      {dayClasses.length} {dayClasses.length === 1 ? "class" : "classes"}
                    </div>
                  </div>
                  <div className="p-2 space-y-2">
                    {dayClasses.length === 0 ? (
                      <div className="px-3 py-6 text-bone/30 text-xs uppercase tracking-[0.15em] text-center">
                        — Rest day —
                      </div>
                    ) : (
                      dayClasses.map((s) => {
                        const d = disciplines.find((x) => x.slug === s.discipline)!;
                        return (
                          <Link
                            key={s.id}
                            href="/contact"
                            className={`group block p-3 border border-bone/10 hover:border-ember hover:bg-ink-800 transition-colors ${
                              s.beginnerFriendly ? "bg-ember/[0.04]" : ""
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-[10px] uppercase tracking-[0.2em] font-semibold text-ember">
                                {disciplineLabel[d.slug]}
                              </span>
                              {s.beginnerFriendly && (
                                <span
                                  className="text-[9px] uppercase tracking-[0.15em] text-bone/40"
                                  title="Beginner welcome"
                                >
                                  ★ Beginner
                                </span>
                              )}
                            </div>
                            <div className="text-bone text-sm font-semibold leading-tight group-hover:text-ember transition-colors">
                              {fmtTime(s.start)} – {fmtTime(s.end)}
                            </div>
                            <div className="text-bone/50 text-xs mt-1">
                              {ageLabel(s.ageGroup)} · {s.level === "all" ? "All levels" : s.level}
                            </div>
                          </Link>
                        );
                      })
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Helpful prompt */}
        <div className="mt-10 grid lg:grid-cols-2 gap-px bg-bone/10 border border-bone/10">
          <div className="bg-ink-950 p-8 lg:p-10">
            <div className="text-ember text-xs uppercase tracking-[0.25em] mb-3">First-timer?</div>
            <h3 className="h-display text-bone text-3xl mb-3">
              We&apos;ll match you to a class.
            </h3>
            <p className="text-bone/60 text-sm leading-relaxed mb-6">
              Tell us your goals and your schedule — we&apos;ll book you into the
              right class with the right coach.
            </p>
            <Link href="/contact" className="btn btn-primary">
              Book my free trial
            </Link>
          </div>
          <div className="bg-ink-950 p-8 lg:p-10">
            <div className="text-ember text-xs uppercase tracking-[0.25em] mb-3">Existing member?</div>
            <h3 className="h-display text-bone text-3xl mb-3">
              Manage your bookings.
            </h3>
            <p className="text-bone/60 text-sm leading-relaxed mb-6">
              Check class availability, change your booking or chat to a coach
              about progression.
            </p>
            <a href="tel:+61731774550" className="btn btn-ghost">
              Call (07) 3177 4550
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

function FilterGroup({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { id: string; label: string }[];
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-bone/40 text-[10px] uppercase tracking-[0.2em] hidden md:inline">
        {label}
      </span>
      <div className="flex gap-1 flex-wrap">
        {options.map((opt) => (
          <button
            key={opt.id}
            onClick={() => onChange(opt.id)}
            className={`px-3 py-1.5 text-xs uppercase tracking-[0.1em] font-medium transition-colors border ${
              value === opt.id
                ? "bg-ember text-ink border-ember"
                : "bg-transparent text-bone/60 border-bone/15 hover:border-bone/40 hover:text-bone"
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>
    </div>
  );
}
