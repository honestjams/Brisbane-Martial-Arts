export default function Marquee({
  items,
  className = "",
}: {
  items: string[];
  className?: string;
}) {
  // Duplicate items for seamless loop
  const doubled = [...items, ...items];
  return (
    <div className={`overflow-hidden border-y border-bone/10 ${className}`}>
      <div className="marquee-track py-6">
        {doubled.map((item, i) => (
          <span
            key={i}
            className="h-display text-3xl md:text-5xl text-bone/80 px-8 whitespace-nowrap flex items-center gap-8"
          >
            {item}
            <span className="text-ember text-2xl">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}
