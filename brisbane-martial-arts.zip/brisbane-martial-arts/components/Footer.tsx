import Link from "next/link";
import Logo from "./Logo";

export default function Footer() {
  return (
    <footer className="relative border-t border-bone/10 bg-ink-950 text-bone">
      {/* Big CTA strip */}
      <div className="border-b border-bone/10">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10 py-16 lg:py-24 grid lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-8">
            <div className="text-ember text-xs uppercase tracking-[0.3em] mb-4 font-medium">
              ✦  Your first class is on us
            </div>
            <h2 className="h-display text-5xl md:text-7xl lg:text-[6.5rem] text-bone">
              Stop watching.<br />
              <span className="text-ember">Start training.</span>
            </h2>
          </div>
          <div className="lg:col-span-4 flex flex-col gap-3">
            <Link href="/contact" className="btn btn-primary">
              Book your free trial
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M5 12h14M13 5l7 7-7 7" />
              </svg>
            </Link>
            <a href="tel:+61731774550" className="btn btn-ghost">
              Call (07) 3177 4550
            </a>
          </div>
        </div>
      </div>

      {/* Main footer grid */}
      <div className="mx-auto max-w-[1400px] px-5 lg:px-10 py-16 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-4">
          <Logo className="h-12 w-auto text-bone mb-6" />
          <p className="text-bone/60 text-sm max-w-xs leading-relaxed">
            Brisbane&apos;s largest dedicated martial arts centre. Four matted halls.
            Ninety-plus classes a week. One serious community.
          </p>
        </div>

        <div className="lg:col-span-2">
          <h4 className="text-xs uppercase tracking-[0.2em] text-bone/40 mb-5">Disciplines</h4>
          <ul className="space-y-3 text-bone/80 text-sm">
            <li><Link href="/classes#taekwondo" className="link-underline">Taekwondo</Link></li>
            <li><Link href="/classes#bjj" className="link-underline">Brazilian Jiu-Jitsu</Link></li>
            <li><Link href="/classes#kravmaga" className="link-underline">Krav Maga</Link></li>
            <li><Link href="/classes#pilates" className="link-underline">Pilates</Link></li>
          </ul>
        </div>

        <div className="lg:col-span-2">
          <h4 className="text-xs uppercase tracking-[0.2em] text-bone/40 mb-5">Centre</h4>
          <ul className="space-y-3 text-bone/80 text-sm">
            <li><Link href="/about" className="link-underline">About BTC</Link></li>
            <li><Link href="/timetable" className="link-underline">Timetable</Link></li>
            <li><Link href="/about#instructors" className="link-underline">Instructors</Link></li>
            <li><Link href="/contact" className="link-underline">Contact</Link></li>
          </ul>
        </div>

        <div className="lg:col-span-4">
          <h4 className="text-xs uppercase tracking-[0.2em] text-bone/40 mb-5">Visit</h4>
          <address className="not-italic space-y-2 text-bone/80 text-sm leading-relaxed">
            <div>BTC Martial Arts Centre</div>
            <div>123 Sample Street, Stafford</div>
            <div>Brisbane QLD 4053</div>
            <div className="pt-2">
              <a href="tel:+61731774550" className="link-underline tabular">(07) 3177 4550</a>
            </div>
            <div>
              <a href="mailto:hello@brisbanemartialarts.com.au" className="link-underline">
                hello@brisbanemartialarts.com.au
              </a>
            </div>
          </address>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-bone/10">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10 py-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs text-bone/40">
          <div>© {new Date().getFullYear()} BTC Brisbane Martial Arts. All rights reserved.</div>
          <div className="flex items-center gap-6">
            <a href="#" className="link-underline">Privacy</a>
            <a href="#" className="link-underline">Terms</a>
            <span className="opacity-60">Crafted in Brisbane.</span>
          </div>
        </div>
      </div>

      {/* Decorative oversized wordmark */}
      <div className="overflow-hidden border-t border-bone/10">
        <div className="h-display text-bone/[0.04] text-[18vw] leading-none whitespace-nowrap text-center select-none">
          BRISBANE
        </div>
      </div>
    </footer>
  );
}
