import Link from "next/link";
import { disciplines } from "@/lib/data";
import { Icon, type IconName } from "@/components/Icons";

export const metadata = {
  title: "Classes — Taekwondo, BJJ, Krav Maga & Pilates | BTC",
  description:
    "Explore the four disciplines taught at BTC: Taekwondo, Brazilian Jiu-Jitsu, Krav Maga and Pilates. Programs for ages 3 through 75+, beginner to black belt.",
};

const iconMap: Record<string, IconName> = {
  taekwondo: "zap",
  bjj: "shield",
  kravmaga: "flame",
  pilates: "leaf",
};

export default function ClassesPage() {
  return (
    <>
      {/* Page hero */}
      <section className="pt-32 lg:pt-44 pb-16 lg:pb-24 bg-ink-900 border-b border-bone/10 relative overflow-hidden">
        <div
          aria-hidden
          className="absolute -top-32 -right-32 w-[600px] h-[600px] rounded-full opacity-20 blur-[120px]"
          style={{ background: "radial-gradient(circle, #FF4D2E, transparent 70%)" }}
        />
        <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10">
          <nav className="text-bone/40 text-xs uppercase tracking-[0.2em] mb-8 flex items-center gap-2" aria-label="Breadcrumb">
            <Link href="/" className="hover:text-bone">Home</Link>
            <span>/</span>
            <span className="text-bone">Classes</span>
          </nav>
          <h1 className="h-display text-bone text-6xl md:text-7xl lg:text-9xl mb-8 reveal">
            Four disciplines.<br />
            <span className="h-serif text-ember italic text-[0.7em]">one membership.</span>
          </h1>
          <p className="text-bone/70 text-lg lg:text-xl max-w-2xl reveal">
            Cross-train across everything we teach, or specialise. Every program
            is split by age and experience level — so you train alongside people
            you can grow with, and from.
          </p>
        </div>
      </section>

      {/* Quick nav */}
      <section className="bg-ink-950 border-b border-bone/10 sticky top-16 lg:top-20 z-30 backdrop-blur-xl bg-ink-950/85">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10 py-4 flex gap-2 overflow-x-auto">
          {disciplines.map((d) => (
            <a
              key={d.slug}
              href={`#${d.slug}`}
              className="flex-shrink-0 px-4 py-2 text-xs uppercase tracking-[0.15em] text-bone/60 hover:text-ember hover:border-ember border border-bone/10 transition-colors"
            >
              {d.short} — {d.name.split(" ")[0]}
            </a>
          ))}
        </div>
      </section>

      {/* Discipline blocks */}
      {disciplines.map((d, i) => (
        <section
          key={d.slug}
          id={d.slug}
          className={`py-24 lg:py-32 ${i % 2 === 0 ? "bg-ink-900" : "bg-ink-950"} scroll-mt-32 relative overflow-hidden`}
        >
          {/* Massive number */}
          <div
            aria-hidden
            className="absolute top-0 right-0 h-display text-bone/[0.03] text-[35vw] leading-[0.75] select-none pointer-events-none -mt-12"
          >
            {d.number}
          </div>

          <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10">
            <div className="grid lg:grid-cols-12 gap-10 lg:gap-16">
              <div className="lg:col-span-5 reveal">
                <div className="text-ember mb-6">
                  <Icon name={iconMap[d.slug]} className="w-10 h-10" />
                </div>
                <div className="text-bone/40 text-xs uppercase tracking-[0.25em] mb-3">
                  Discipline {d.number} · Origin: {d.origin}
                </div>
                <h2 className="h-display text-bone text-5xl md:text-6xl lg:text-7xl mb-4">
                  {d.name}
                </h2>
                <p className="h-serif text-ember italic text-2xl mb-8">
                  {d.tagline}.
                </p>
                <p className="text-bone/70 text-base lg:text-lg leading-relaxed mb-10 max-w-md">
                  {d.description}
                </p>

                <div className="flex flex-wrap gap-x-8 gap-y-4 mb-10">
                  <div>
                    <div className="text-bone/40 text-[10px] uppercase tracking-[0.2em] mb-1">Ages</div>
                    <div className="text-bone text-lg font-semibold tabular">{d.ages}</div>
                  </div>
                  <div>
                    <div className="text-bone/40 text-[10px] uppercase tracking-[0.2em] mb-2">Intensity</div>
                    <div className="flex gap-1.5 mt-2">
                      {[1, 2, 3, 4, 5].map((n) => (
                        <span
                          key={n}
                          className={`block w-6 h-[3px] ${
                            n <= d.intensity ? "bg-ember" : "bg-bone/15"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-3">
                  <Link href="/contact" className="btn btn-primary">
                    Try a free class
                  </Link>
                  <Link href="/timetable" className="btn btn-ghost">
                    See the timetable
                  </Link>
                </div>
              </div>

              <div className="lg:col-span-6 lg:col-start-7 reveal">
                <div className="text-bone/40 text-xs uppercase tracking-[0.25em] mb-6">
                  What you&apos;ll get
                </div>
                <ul className="space-y-px bg-bone/10 border border-bone/10">
                  {d.benefits.map((benefit) => (
                    <li
                      key={benefit}
                      className="bg-ink-900 hover:bg-ink-800 px-6 py-5 flex items-center justify-between gap-4 transition-colors"
                    >
                      <span className="text-bone text-base lg:text-lg">{benefit}</span>
                      <span className="text-ember">
                        <Icon name="check" />
                      </span>
                    </li>
                  ))}
                </ul>

                {/* Pull quote */}
                <div className="mt-10 p-8 lg:p-10 border border-bone/10 bg-ink-950/50">
                  <div className="text-ember mb-4 text-3xl">&ldquo;</div>
                  <p className="h-serif italic text-bone/90 text-xl lg:text-2xl leading-snug">
                    The classes meet you where you are. I&apos;ve never felt out
                    of place — and I&apos;ve also never stopped being challenged.
                  </p>
                  <div className="mt-6 text-bone/50 text-sm uppercase tracking-[0.15em]">
                    — Member, {d.name}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      ))}
    </>
  );
}
