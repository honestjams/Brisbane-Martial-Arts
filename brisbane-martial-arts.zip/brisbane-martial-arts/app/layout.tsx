import type { Metadata } from "next";
import { Anton, Instrument_Serif, DM_Sans } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ScrollReveal from "@/components/ScrollReveal";

const display = Anton({
  subsets: ["latin"],
  weight: ["400"],
  variable: "--font-display",
  display: "swap",
});

const serif = Instrument_Serif({
  subsets: ["latin"],
  weight: ["400"],
  style: ["normal", "italic"],
  variable: "--font-serif",
  display: "swap",
});

const sans = DM_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-sans",
  display: "swap",
});

export const metadata: Metadata = {
  title: "BTC — Brisbane Martial Arts | Taekwondo, BJJ, Krav Maga, Pilates",
  description:
    "Brisbane's largest martial arts centre. 90+ weekly classes in Taekwondo, Brazilian Jiu-Jitsu, Krav Maga and Pilates. All ages 3–75. Book your free trial today.",
  metadataBase: new URL("https://brisbanemartialarts.example.com"),
  openGraph: {
    title: "BTC — Brisbane Martial Arts",
    description:
      "Brisbane's largest martial arts centre. Train Taekwondo, BJJ, Krav Maga & Pilates. Free trial class available.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${display.variable} ${serif.variable} ${sans.variable}`}
    >
      <body className="grain">
        <ScrollReveal />
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
