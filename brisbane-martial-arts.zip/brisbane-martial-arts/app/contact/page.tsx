import Link from "next/link";
import ContactForm from "@/components/ContactForm";
import { faqs } from "@/lib/data";

export const metadata = {
  title: "Contact — Book a Free Trial Class | BTC Brisbane Martial Arts",
  description:
    "Book your free trial class at Brisbane's largest martial arts centre. Call (07) 3177 4550 or send us a message — we'll be in touch within one business day.",
};

export default function ContactPage() {
  return (
    <>
      {/* Hero */}
      <section className="pt-32 lg:pt-44 pb-12 lg:pb-16 bg-ink-900 relative overflow-hidden border-b border-bone/10">
        <div
          aria-hidden
          className="absolute -bottom-32 -right-32 w-[600px] h-[600px] rounded-full opacity-20 blur-[120px]"
          style={{ background: "radial-gradient(circle, #FF4D2E, transparent 70%)" }}
        />
        <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10">
          <nav className="text-bone/40 text-xs uppercase tracking-[0.2em] mb-8 flex items-center gap-2" aria-label="Breadcrumb">
            <Link href="/" className="hover:text-bone">Home</Link>
            <span>/</span>
            <span className="text-bone">Contact</span>
          </nav>
          <div className="grid lg:grid-cols-12 gap-8 items-end">
            <div className="lg:col-span-8 reveal">
              <h1 className="h-display text-bone text-6xl md:text-7xl lg:text-9xl">
                Let&apos;s get<br />
                <span className="h-serif text-ember italic text-[0.7em]">you on the mat.</span>
              </h1>
            </div>
            <div className="lg:col-span-4 reveal">
              <p className="text-bone/70 text-base leading-relaxed">
                Pick up the phone, drop us a line, or fill in the form. Your
                first class is on us — no contracts, no pressure.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Form + info */}
      <section className="py-20 lg:py-28 bg-ink-950">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="grid lg:grid-cols-12 gap-12 lg:gap-20">
            {/* Form */}
            <div className="lg:col-span-7 reveal">
              <div className="text-ember text-xs uppercase tracking-[0.3em] mb-6 flex items-center gap-3">
                <span className="w-8 h-px bg-ember" />
                <span>Free trial booking</span>
              </div>
              <h2 className="h-display text-bone text-4xl lg:text-5xl mb-10">
                Tell us a bit<br />about you.
              </h2>
              <ContactForm />
            </div>

            {/* Info column */}
            <div className="lg:col-span-4 lg:col-start-9 space-y-10 reveal">
              <div>
                <div className="text-bone/40 text-[10px] uppercase tracking-[0.25em] mb-3">Phone</div>
                <a
                  href="tel:+61731774550"
                  className="h-display text-bone text-4xl hover:text-ember transition-colors tabular block"
                >
                  3177 4550
                </a>
                <div className="text-bone/50 text-sm mt-2">Mon–Sat, reception hours</div>
              </div>

              <div>
                <div className="text-bone/40 text-[10px] uppercase tracking-[0.25em] mb-3">Email</div>
                <a
                  href="mailto:hello@brisbanemartialarts.com.au"
                  className="text-bone text-base hover:text-ember transition-colors break-all link-underline"
                >
                  hello@brisbanemartialarts.com.au
                </a>
              </div>

              <div>
                <div className="text-bone/40 text-[10px] uppercase tracking-[0.25em] mb-3">Visit</div>
                <address className="not-italic text-bone text-base leading-relaxed">
                  BTC Martial Arts Centre<br />
                  123 Sample Street<br />
                  Stafford, Brisbane QLD 4053
                </address>
                <a
                  href="https://maps.google.com/?q=Stafford+Brisbane+QLD"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-ember text-sm mt-4 link-underline"
                >
                  Get directions
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M7 17L17 7M17 7H7M17 7V17" />
                  </svg>
                </a>
              </div>

              <div>
                <div className="text-bone/40 text-[10px] uppercase tracking-[0.25em] mb-3">Reception hours</div>
                <ul className="space-y-1 text-bone text-sm tabular">
                  <li className="flex justify-between"><span>Mon–Thu</span><span className="text-bone/60">9am – 9pm</span></li>
                  <li className="flex justify-between"><span>Friday</span><span className="text-bone/60">9am – 8pm</span></li>
                  <li className="flex justify-between"><span>Saturday</span><span className="text-bone/60">8am – 12pm</span></li>
                  <li className="flex justify-between"><span>Sunday</span><span className="text-bone/60">Closed</span></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-24 lg:py-32 bg-ink-900 border-t border-bone/10">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="grid lg:grid-cols-12 gap-12">
            <div className="lg:col-span-4 reveal">
              <div className="sticky top-32">
                <div className="text-ember text-xs uppercase tracking-[0.3em] mb-6 flex items-center gap-3">
                  <span className="w-8 h-px bg-ember" />
                  <span>FAQs</span>
                </div>
                <h2 className="h-display text-bone text-5xl lg:text-6xl">
                  Common<br />questions.
                </h2>
                <p className="text-bone/60 text-sm mt-6 leading-relaxed">
                  Can&apos;t find what you&apos;re after? Give us a call —
                  we&apos;d rather have a quick chat than leave you guessing.
                </p>
              </div>
            </div>

            <div className="lg:col-span-7 lg:col-start-6 reveal">
              <ul className="divide-y divide-bone/10 border-y border-bone/10">
                {faqs.map((faq, i) => (
                  <li key={i}>
                    <details className="group">
                      <summary className="cursor-pointer list-none py-6 flex items-start justify-between gap-6 hover:bg-ink-800/40 transition-colors px-2 -mx-2">
                        <span className="text-bone text-lg lg:text-xl font-medium pr-4">
                          {faq.q}
                        </span>
                        <span className="flex-shrink-0 text-ember mt-1 group-open:rotate-45 transition-transform duration-300">
                          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M12 5v14M5 12h14" />
                          </svg>
                        </span>
                      </summary>
                      <div className="pb-6 pr-12 -mt-1">
                        <p className="text-bone/70 text-base leading-relaxed">
                          {faq.a}
                        </p>
                      </div>
                    </details>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
