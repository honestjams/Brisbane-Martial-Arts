import Link from "next/link";
import TimetableInteractive from "@/components/TimetableInteractive";

export const metadata = {
  title: "Timetable — Weekly Class Schedule | BTC Brisbane Martial Arts",
  description:
    "Browse 90+ weekly classes across Taekwondo, BJJ, Krav Maga and Pilates. Filter by discipline, age and level to find the right class for you.",
};

export default function TimetablePage() {
  return (
    <>
      <section className="pt-32 lg:pt-44 pb-12 lg:pb-16 bg-ink-900 relative overflow-hidden">
        <div
          aria-hidden
          className="absolute -top-32 -left-32 w-[600px] h-[600px] rounded-full opacity-20 blur-[120px]"
          style={{ background: "radial-gradient(circle, #FF4D2E, transparent 70%)" }}
        />
        <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10">
          <nav className="text-bone/40 text-xs uppercase tracking-[0.2em] mb-8 flex items-center gap-2" aria-label="Breadcrumb">
            <Link href="/" className="hover:text-bone">Home</Link>
            <span>/</span>
            <span className="text-bone">Timetable</span>
          </nav>
          <div className="grid lg:grid-cols-12 gap-8 items-end">
            <div className="lg:col-span-8 reveal">
              <h1 className="h-display text-bone text-6xl md:text-7xl lg:text-9xl">
                Find your<br />
                <span className="h-serif text-ember italic text-[0.7em]">first class.</span>
              </h1>
            </div>
            <div className="lg:col-span-4 reveal">
              <p className="text-bone/70 text-base leading-relaxed">
                Filter by what you want to train, your age group, or whether
                you&apos;re brand new. Tap any class to book a free trial in
                that slot.
              </p>
            </div>
          </div>
        </div>
      </section>

      <TimetableInteractive />
    </>
  );
}
