import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import DisciplineGrid from "@/components/DisciplineGrid";
import Story from "@/components/Story";
import BeginnersStrip from "@/components/BeginnersStrip";
import Testimonials from "@/components/Testimonials";

export default function Home() {
  return (
    <>
      <Hero />
      <Marquee
        items={[
          "Taekwondo",
          "Brazilian Jiu-Jitsu",
          "Krav Maga",
          "Pilates",
          "Self-Defence",
          "Strength",
          "Sparring",
          "Discipline",
        ]}
      />
      <DisciplineGrid />
      <Story />
      <BeginnersStrip />
      <Testimonials />
    </>
  );
}
