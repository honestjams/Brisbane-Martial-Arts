import Link from "next/link";
import { instructors, stats } from "@/lib/data";

export const metadata = {
  title: "About — Brisbane's Largest Martial Arts Centre | BTC",
  description:
    "BTC is Brisbane's largest dedicated martial arts centre. Four halls, expert coaches, and a community of members aged 3 to 75. Read our story.",
};

export default function AboutPage() {
  return (
    <>
      {/* Hero */}
      <section className="pt-32 lg:pt-44 pb-16 lg:pb-24 bg-ink-900 relative overflow-hidden border-b border-bone/10">
        <div
          aria-hidden
          className="absolute top-0 right-0 h-display text-bone/[0.03] text-[40vw] leading-[0.75] select-none pointer-events-none -mt-12"
        >
          BTC
        </div>
        <div className="relative mx-auto max-w-[1400px] px-5 lg:px-10">
          <nav className="text-bone/40 text-xs uppercase tracking-[0.2em] mb-8 flex items-center gap-2" aria-label="Breadcrumb">
            <Link href="/" className="hover:text-bone">Home</Link>
            <span>/</span>
            <span className="text-bone">About</span>
          </nav>
          <h1 className="h-display text-bone text-6xl md:text-7xl lg:text-9xl mb-8 reveal">
            We built
            <br />
            the gym <span className="h-serif text-ember italic text-[0.7em]">we wanted</span>
            <br />
            to train at.
          </h1>
        </div>
      </section>

      {/* Story */}
      <section className="py-24 lg:py-32 bg-ink-950">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="grid lg:grid-cols-12 gap-12">
            <div className="lg:col-span-4 reveal">
              <div className="flex items-center gap-3 text-ember text-xs uppercase tracking-[0.3em] mb-6">
                <span className="w-8 h-px bg-ember" />
                <span>Our story</span>
              </div>
              <h2 className="h-display text-bone text-4xl lg:text-5xl">
                Twenty years.<br />
                One mission.
              </h2>
            </div>
            <div className="lg:col-span-7 lg:col-start-6 space-y-6 reveal">
              <p className="text-bone/85 text-2xl lg:text-3xl leading-snug font-light">
                For two decades, BTC has done one thing: build a martial arts
                centre serious enough for competitors and welcoming enough for
                a three-year-old&apos;s first class.
              </p>
              <p className="text-bone/65 text-base lg:text-lg leading-relaxed">
                Most martial arts gyms run a single discipline out of a shared
                hall. We took the opposite bet — four dedicated, fully-matted,
                air-conditioned training halls running classes simultaneously
                across Taekwondo, Brazilian Jiu-Jitsu, Krav Maga and Pilates.
                That decision lets us teach more disciplines, more deeply, with
                specialist coaches in each one.
              </p>
              <p className="text-bone/65 text-base lg:text-lg leading-relaxed">
                Today the centre runs ninety-plus classes a week. Members range
                from preschoolers in our Tigers program to a black belt in his
                seventies. The mats fill up morning, afternoon, evening and
                weekends — and that, more than anything, is what we&apos;re proud
                of.
              </p>
            </div>
          </div>

          {/* Stats */}
          <div className="mt-20 grid grid-cols-2 lg:grid-cols-4 gap-px bg-bone/10 border border-bone/10 reveal">
            {stats.map((s) => (
              <div key={s.label} className="bg-ink-950 p-6 lg:p-10">
                <div className="h-display text-bone text-5xl lg:text-6xl tabular">
                  {s.value}
                </div>
                <div className="text-bone/50 text-xs uppercase tracking-[0.2em] mt-2">
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Facilities */}
      <section className="py-24 lg:py-32 bg-ink-900 border-y border-bone/10">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="mb-16 reveal">
            <div className="flex items-center gap-3 text-ember text-xs uppercase tracking-[0.3em] mb-6">
              <span className="w-8 h-px bg-ember" />
              <span>The centre</span>
            </div>
            <h2 className="h-display text-bone text-5xl lg:text-7xl max-w-3xl">
              Built for the work.
            </h2>
          </div>

          <div className="grid lg:grid-cols-3 gap-px bg-bone/10 border border-bone/10 reveal">
            {[
              {
                title: "Four training halls",
                desc: "Each fully matted, air-conditioned, and dedicated to its discipline. No setup, no breakdown, no waiting on the next group.",
                num: "01",
              },
              {
                title: "Onsite gym",
                desc: "A full strength and conditioning floor for warm-ups, supplementary work, or a session in its own right — included with membership.",
                num: "02",
              },
              {
                title: "Pro shop & change rooms",
                desc: "Pick up a uniform, shin guards, mouth guards or rashies on your way in or out. Lockers, showers, and a comfortable lounge.",
                num: "03",
              },
            ].map((f) => (
              <div key={f.title} className="bg-ink-900 p-8 lg:p-10">
                <div className="h-display text-ember/40 text-5xl mb-6 tabular">{f.num}</div>
                <h3 className="h-display text-bone text-3xl mb-3">{f.title}</h3>
                <p className="text-bone/60 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Instructors */}
      <section id="instructors" className="py-24 lg:py-32 bg-ink-950">
        <div className="mx-auto max-w-[1400px] px-5 lg:px-10">
          <div className="grid lg:grid-cols-12 gap-8 mb-16 items-end">
            <div className="lg:col-span-7 reveal">
              <div className="flex items-center gap-3 text-ember text-xs uppercase tracking-[0.3em] mb-6">
                <span className="w-8 h-px bg-ember" />
                <span>The coaches</span>
              </div>
              <h2 className="h-display text-bone text-5xl md:text-6xl lg:text-7xl">
                Who you&apos;ll train with.
              </h2>
            </div>
            <div className="lg:col-span-4 lg:col-start-9 reveal">
              <p className="text-bone/60 text-base leading-relaxed">
                Every instructor at BTC is a specialist in their discipline —
                with the certifications, mat hours, and humility that make a
                great coach.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-px bg-bone/10 border border-bone/10">
            {instructors.map((person, i) => (
              <div key={person.name} className="bg-ink-950 p-8 lg:p-10 group hover:bg-ink-900 transition-colors reveal" style={{ transitionDelay: `${i * 60}ms` }}>
                <div className="flex items-start gap-6 mb-6">
                  <div className="w-16 h-16 border-2 border-ember flex items-center justify-center h-display text-ember text-2xl flex-shrink-0">
                    {person.name.split(" ").map((p) => p[0]).join("").slice(0, 2)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-ember text-[10px] uppercase tracking-[0.25em] mb-1">
                      {person.disciplines.join(" · ")}
                    </div>
                    <h3 className="h-display text-bone text-3xl leading-tight">{person.name}</h3>
                    <div className="text-bone/50 text-sm mt-1">{person.rank}</div>
                  </div>
                </div>
                <p className="text-bone/70 text-sm lg:text-base leading-relaxed">
                  {person.bio}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
