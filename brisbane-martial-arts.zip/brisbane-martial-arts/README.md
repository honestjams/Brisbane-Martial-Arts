# BTC — Brisbane Martial Arts

A modern, cinematic recreation of the Brisbane Martial Arts website. Built with **Next.js 14** (App Router), **TypeScript**, and **Tailwind CSS** — fully static, fast, and Vercel-ready.

---

## What's inside

| Page | Path | Notes |
|---|---|---|
| Home | `/` | Hero, marquee, disciplines grid, story, beginners-friendly classes, testimonials |
| Classes | `/classes` | Full writeup of each discipline (TKD / BJJ / Krav Maga / Pilates) |
| Timetable | `/timetable` | **Interactive filterable grid** by discipline, age, level |
| About | `/about` | Story, stats, facilities, instructor profiles |
| Contact | `/contact` | Trial-class booking form + FAQs (accordion) |

### Design system

- **Display type:** Anton (heavy condensed)
- **Editorial accent:** Instrument Serif italics
- **Body:** DM Sans
- **Palette:** Ink (near-black) · Bone (warm cream) · Ember (#FF4D2E)
- Custom grain overlay, scroll-reveal animations, marquee strip, custom scrollbar

---

## Run locally

You'll need **Node.js 18.17+** installed.

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

To produce a production build locally:

```bash
npm run build
npm run start
```

---

## Deploy to Vercel

You have **two options**. The CLI route is fastest if you have `node` installed; the Git route is what you'll want long-term so updates auto-deploy.

### Option A — Vercel CLI (5 minutes, no Git required)

```bash
# 1. Install Vercel CLI globally
npm i -g vercel

# 2. From inside the project folder, log in
cd brisbane-martial-arts
vercel login

# 3. Deploy
vercel
```

You'll be prompted with a few questions — accept the defaults:

- *"Set up and deploy?"* → **Y**
- *"Which scope?"* → pick your personal account
- *"Link to existing project?"* → **N**
- *"What's your project's name?"* → `brisbane-martial-arts` (or anything)
- *"In which directory is your code located?"* → `./`
- *"Want to override the settings?"* → **N**

Vercel auto-detects Next.js and deploys. You'll get a preview URL in ~60 seconds.

To promote to production:

```bash
vercel --prod
```

### Option B — Git + Vercel Dashboard (recommended for ongoing updates)

1. **Create a GitHub repo** (private or public — your choice)
2. **Push this code** to it:
   ```bash
   cd brisbane-martial-arts
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin git@github.com:YOUR_USERNAME/brisbane-martial-arts.git
   git push -u origin main
   ```
3. Go to **[vercel.com/new](https://vercel.com/new)**, import the repo
4. Vercel auto-detects Next.js — leave all settings as-is, click **Deploy**
5. Done. Every future `git push` triggers a new deploy automatically.

### Custom domain

In the Vercel dashboard → **Project → Settings → Domains** → add `brisbanemartialarts.com.au`. Vercel walks you through DNS records (an `A` record and/or `CNAME`). Free SSL is included.

---

## What to customise next

These are intentional placeholders — swap them for the real thing:

1. **Phone number** — currently `(07) 3177 4550` (search for `731774550` and `3177 4550`)
2. **Address** — currently a placeholder Stafford address (search `123 Sample Street` in `Footer.tsx` and `app/contact/page.tsx`)
3. **Email** — `hello@brisbanemartialarts.com.au` (search globally)
4. **Reception hours** — in `app/contact/page.tsx`
5. **Instructor names & bios** — in `lib/data.ts` (currently composite/illustrative based on public info)
6. **Real timetable** — `lib/data.ts` has a full sample timetable; replace times with the live schedule
7. **Contact form backend** — currently shows a success state but doesn't send anywhere. See "Wiring the form" below
8. **Photography** — the design uses pure typography + abstract backgrounds for atmosphere. Drop in real photos when you have them (best places: Hero background, Story section, Instructor cards)

### Wiring the contact form

The form (`components/ContactForm.tsx`) is currently a UI-only mock. Easiest options:

- **Vercel Form Handler** — drop in a serverless function under `app/api/contact/route.ts` and POST to it
- **Formspree / Basin / Web3Forms** — change the `<form>` action to your endpoint, no backend code needed
- **Resend / SendGrid** — for actual email delivery, wire up via an API route

Happy to scaffold any of these — just ask.

---

## File structure

```
brisbane-martial-arts/
├── app/
│   ├── layout.tsx              # Fonts, header, footer wrapper
│   ├── globals.css             # Design tokens, utilities
│   ├── page.tsx                # Home
│   ├── classes/page.tsx
│   ├── timetable/page.tsx
│   ├── about/page.tsx
│   └── contact/page.tsx
├── components/
│   ├── Header.tsx              # Sticky nav + mobile menu
│   ├── Footer.tsx              # Big CTA + footer
│   ├── Logo.tsx                # SVG monogram
│   ├── Hero.tsx
│   ├── DisciplineGrid.tsx
│   ├── Story.tsx
│   ├── Testimonials.tsx        # Auto-rotating, click-to-jump
│   ├── BeginnersStrip.tsx
│   ├── Marquee.tsx
│   ├── ContactForm.tsx
│   ├── TimetableInteractive.tsx
│   ├── ScrollReveal.tsx        # IntersectionObserver hook
│   └── Icons.tsx
├── lib/
│   └── data.ts                 # All content: disciplines, sessions, testimonials, FAQs
├── tailwind.config.ts
├── tsconfig.json
├── next.config.js
└── package.json
```

---

## Performance & accessibility notes

- All pages are statically pre-rendered (`○ Static` in build output)
- First-load JS is ~95–100KB across pages
- Semantic landmarks (`<header>`, `<nav>`, `<main>`, `<footer>`, `<address>`)
- Visible focus states preserved on all interactives
- Accordion uses native `<details>`/`<summary>` (works with keyboard + screen readers out of the box)
- Reduced-motion users still get reveal content (animation falls back to instant via `is-visible` class application)
- Color contrast on body text: bone on ink ≈ 13:1 (well above WCAG AAA)

If you want me to push further on a11y (e.g. `prefers-reduced-motion` media query in CSS, skip-link, ARIA-live for the testimonial rotator), say the word.

---

## Questions or changes?

The site is intentionally easy to modify — most copy and structure lives in `lib/data.ts`, and the design tokens (colors, fonts, spacing) live in `tailwind.config.ts` + `app/globals.css`.
