export type Discipline = {
  slug: "taekwondo" | "bjj" | "kravmaga" | "pilates";
  name: string;
  short: string;
  origin: string;
  tagline: string;
  description: string;
  benefits: string[];
  ages: string;
  intensity: 1 | 2 | 3 | 4 | 5;
  accent: string; // hex
  number: string;
};

export const disciplines: Discipline[] = [
  {
    slug: "taekwondo",
    name: "Taekwondo",
    short: "TKD",
    origin: "Korea",
    tagline: "The art of striking with discipline",
    description:
      "Dynamic kicking, sharp hand techniques and the structure of belt progression. Our adults' taekwondo is one of Queensland's premier programs — and for kids, classes are split by age and level so every child trains in a safe, fun, challenging environment.",
    benefits: [
      "Cardio & explosive power",
      "Flexibility & coordination",
      "Belt progression structure",
      "Confidence and respect",
    ],
    ages: "3 – 75+",
    intensity: 3,
    accent: "#FF4D2E",
    number: "01",
  },
  {
    slug: "bjj",
    name: "Brazilian Jiu-Jitsu",
    short: "BJJ",
    origin: "Brazil",
    tagline: "The gentle art of leverage",
    description:
      "Ground-fighting and grappling that lets a smaller, technical practitioner control a larger opponent. Our BJJ program runs from fundamentals through to advanced, with open-mat sessions for live training.",
    benefits: [
      "Real-world self-defence",
      "Problem-solving on the mat",
      "Total-body conditioning",
      "Tight-knit training culture",
    ],
    ages: "5 – 70+",
    intensity: 4,
    accent: "#FF4D2E",
    number: "02",
  },
  {
    slug: "kravmaga",
    name: "Krav Maga",
    short: "KRV",
    origin: "Israel",
    tagline: "Built for the street, not the ring",
    description:
      "The self-defence system developed for the Israeli Defence Forces. No belts, no sparring rules — just direct, instinct-based responses to real-world threats taught by experienced instructors.",
    benefits: [
      "Practical street self-defence",
      "Threat awareness & de-escalation",
      "High-intensity conditioning",
      "Weapons & multiple-attacker drills",
    ],
    ages: "16 – 65+",
    intensity: 5,
    accent: "#FF4D2E",
    number: "03",
  },
  {
    slug: "pilates",
    name: "Pilates",
    short: "PIL",
    origin: "Germany",
    tagline: "Strength, length, recovery",
    description:
      "Mat-based Pilates that complements every martial art we teach — building the deep core stability, flexibility and body awareness that makes the rest of your training sharper and your body more resilient.",
    benefits: [
      "Deep core strength",
      "Posture & alignment",
      "Injury prevention",
      "Active recovery",
    ],
    ages: "16 – 75+",
    intensity: 2,
    accent: "#C8A55B",
    number: "04",
  },
];

// Timetable
export type Day = "mon" | "tue" | "wed" | "thu" | "fri" | "sat";
export const days: { id: Day; name: string; short: string }[] = [
  { id: "mon", name: "Monday", short: "Mon" },
  { id: "tue", name: "Tuesday", short: "Tue" },
  { id: "wed", name: "Wednesday", short: "Wed" },
  { id: "thu", name: "Thursday", short: "Thu" },
  { id: "fri", name: "Friday", short: "Fri" },
  { id: "sat", name: "Saturday", short: "Sat" },
];

export type AgeGroup =
  | "kids-3-5"
  | "kids-6-8"
  | "kids-9-12"
  | "teens"
  | "adults";

export const ageGroups: { id: AgeGroup; label: string }[] = [
  { id: "kids-3-5", label: "Tigers (3–5)" },
  { id: "kids-6-8", label: "Juniors (6–8)" },
  { id: "kids-9-12", label: "Cadets (9–12)" },
  { id: "teens", label: "Teens (13–17)" },
  { id: "adults", label: "Adults (18+)" },
];

export type ClassSession = {
  id: string;
  discipline: Discipline["slug"];
  ageGroup: AgeGroup;
  day: Day;
  start: string; // "18:15"
  end: string;   // "19:30"
  beginnerFriendly: boolean;
  level: "all" | "beginner" | "intermediate" | "advanced" | "open-mat";
  hall: 1 | 2 | 3 | 4;
};

const t = (
  id: string,
  discipline: Discipline["slug"],
  ageGroup: AgeGroup,
  day: Day,
  start: string,
  end: string,
  beginnerFriendly: boolean,
  level: ClassSession["level"] = "all",
  hall: ClassSession["hall"] = 1
): ClassSession => ({
  id,
  discipline,
  ageGroup,
  day,
  start,
  end,
  beginnerFriendly,
  level,
  hall,
});

export const sessions: ClassSession[] = [
  // === TAEKWONDO — KIDS ===
  t("tkd-tigers-1", "taekwondo", "kids-3-5", "mon", "15:35", "16:05", true, "beginner", 1),
  t("tkd-tigers-2", "taekwondo", "kids-3-5", "wed", "15:35", "16:05", true, "beginner", 1),
  t("tkd-tigers-3", "taekwondo", "kids-3-5", "sat", "09:15", "09:45", true, "beginner", 1),
  t("tkd-juniors-1", "taekwondo", "kids-6-8", "mon", "16:10", "16:50", true, "all", 1),
  t("tkd-juniors-2", "taekwondo", "kids-6-8", "tue", "16:50", "17:30", true, "all", 1),
  t("tkd-juniors-3", "taekwondo", "kids-6-8", "wed", "16:10", "16:50", true, "all", 1),
  t("tkd-juniors-4", "taekwondo", "kids-6-8", "thu", "16:50", "17:30", true, "all", 1),
  t("tkd-juniors-5", "taekwondo", "kids-6-8", "sat", "09:45", "10:30", true, "all", 1),
  t("tkd-cadets-1", "taekwondo", "kids-9-12", "mon", "17:00", "17:50", true, "all", 1),
  t("tkd-cadets-2", "taekwondo", "kids-9-12", "wed", "17:00", "17:50", true, "all", 1),
  t("tkd-cadets-3", "taekwondo", "kids-9-12", "fri", "17:00", "17:50", false, "intermediate", 1),
  t("tkd-cadets-4", "taekwondo", "kids-9-12", "sat", "10:30", "11:30", true, "all", 1),

  // === TAEKWONDO — TEENS / ADULTS ===
  t("tkd-adults-mon", "taekwondo", "adults", "mon", "18:15", "19:30", true, "all", 2),
  t("tkd-adults-tue-am", "taekwondo", "adults", "tue", "11:00", "12:00", true, "all", 2),
  t("tkd-adults-tue", "taekwondo", "adults", "tue", "18:15", "19:30", true, "all", 2),
  t("tkd-adults-wed", "taekwondo", "adults", "wed", "18:15", "19:30", false, "intermediate", 2),
  t("tkd-adults-thu-am", "taekwondo", "adults", "thu", "11:00", "12:00", true, "all", 2),
  t("tkd-adults-thu", "taekwondo", "adults", "thu", "18:15", "19:30", true, "all", 2),
  t("tkd-adults-sat", "taekwondo", "adults", "sat", "08:15", "09:15", true, "all", 2),
  t("tkd-blackbelt", "taekwondo", "adults", "fri", "18:30", "20:00", false, "advanced", 2),
  t("tkd-sparring", "taekwondo", "teens", "wed", "19:30", "20:30", false, "intermediate", 2),

  // === BJJ ===
  t("bjj-kids-mon", "bjj", "kids-6-8", "mon", "16:30", "17:15", true, "all", 3),
  t("bjj-kids-wed", "bjj", "kids-6-8", "wed", "16:30", "17:15", true, "all", 3),
  t("bjj-cadets-tue", "bjj", "kids-9-12", "tue", "17:30", "18:15", true, "all", 3),
  t("bjj-cadets-thu", "bjj", "kids-9-12", "thu", "17:30", "18:15", true, "all", 3),
  t("bjj-fund-mon", "bjj", "adults", "mon", "19:30", "20:30", true, "beginner", 3),
  t("bjj-adv-mon", "bjj", "adults", "mon", "20:30", "21:30", false, "advanced", 3),
  t("bjj-fund-tue", "bjj", "adults", "tue", "19:00", "20:00", true, "beginner", 3),
  t("bjj-fund-wed", "bjj", "adults", "wed", "19:30", "20:30", true, "beginner", 3),
  t("bjj-adv-wed", "bjj", "adults", "wed", "20:30", "21:30", false, "advanced", 3),
  t("bjj-fund-thu", "bjj", "adults", "thu", "19:00", "20:00", true, "beginner", 3),
  t("bjj-fund-fri", "bjj", "adults", "fri", "19:00", "20:00", true, "beginner", 3),
  t("bjj-openmat-sat", "bjj", "adults", "sat", "10:30", "12:00", false, "open-mat", 3),

  // === KRAV MAGA ===
  t("krv-fund-mon", "kravmaga", "adults", "mon", "19:15", "20:30", true, "beginner", 4),
  t("krv-int-mon", "kravmaga", "adults", "mon", "20:30", "21:30", false, "intermediate", 4),
  t("krv-fund-tue", "kravmaga", "adults", "tue", "18:00", "19:00", true, "beginner", 4),
  t("krv-fund-wed", "kravmaga", "adults", "wed", "19:15", "20:30", true, "beginner", 4),
  t("krv-adv-wed", "kravmaga", "adults", "wed", "20:30", "21:30", false, "advanced", 4),
  t("krv-fund-thu", "kravmaga", "adults", "thu", "18:00", "19:00", true, "beginner", 4),
  t("krv-women-thu", "kravmaga", "adults", "thu", "19:30", "20:30", true, "beginner", 4),
  t("krv-sat", "kravmaga", "adults", "sat", "08:15", "09:15", true, "all", 4),

  // === PILATES ===
  t("pil-mon", "pilates", "adults", "mon", "06:30", "07:30", true, "all", 1),
  t("pil-tue", "pilates", "adults", "tue", "06:30", "07:30", true, "all", 1),
  t("pil-wed-am", "pilates", "adults", "wed", "06:30", "07:30", true, "all", 1),
  t("pil-wed-pm", "pilates", "adults", "wed", "18:30", "19:30", true, "all", 1),
  t("pil-thu", "pilates", "adults", "thu", "06:30", "07:30", true, "all", 1),
  t("pil-fri", "pilates", "adults", "fri", "06:30", "07:30", true, "all", 1),
  t("pil-sat", "pilates", "adults", "sat", "07:30", "08:30", true, "all", 1),
];

export const stats = [
  { value: "90+", label: "Classes weekly" },
  { value: "4", label: "Training halls" },
  { value: "3—75", label: "Years of age" },
  { value: "20+", label: "Years coaching" },
];

export type Testimonial = {
  quote: string;
  name: string;
  role: string;
};

export const testimonials: Testimonial[] = [
  {
    quote:
      "BTC has a really great atmosphere. The facilities are the best I've seen in a martial arts centre and the training itself is world-class.",
    name: "Amanda",
    role: "Adult Member, Pilates & TKD",
  },
  {
    quote:
      "Since starting at BTC I have noticed big differences in my flexibility, strength and endurance. The classes are challenging but always welcoming.",
    name: "Sally",
    role: "Self-defence, Toowong",
  },
  {
    quote:
      "Everyone has noticed my son's behaviour changes after just a few sessions. He's calmer, more focused, and genuinely loves coming back every week.",
    name: "Michael",
    role: "Parent, Enoggera",
  },
  {
    quote:
      "I've trained at gyms my whole life. Nothing compares to the community here — the coaches actually know your name and your goals.",
    name: "Karen",
    role: "Self-defence, Lutwyche",
  },
  {
    quote:
      "Six weeks in and the changes — mental and physical — are well beyond what I expected from a fitness regime. Best decision I've made this year.",
    name: "Mark",
    role: "Adult Member, BJJ",
  },
];

export type Instructor = {
  name: string;
  rank: string;
  disciplines: string[];
  bio: string;
};

export const instructors: Instructor[] = [
  {
    name: "Master Gav",
    rank: "Australasia's Most Senior Krav Maga Instructor",
    disciplines: ["Krav Maga", "Self-Defence"],
    bio: "Three decades of self-defence coaching across military, law-enforcement and civilian programs. Direct lineage from the Israeli system founders.",
  },
  {
    name: "Master Peter",
    rank: "7th Dan Black Belt",
    disciplines: ["Taekwondo", "Hapkido"],
    bio: "Head of the BTC Taekwondo program. Has coached Australian national-team competitors and worked with hundreds of children with ADHD, autism and anxiety.",
  },
  {
    name: "Coach Andre",
    rank: "Black Belt — Brazilian Jiu-Jitsu",
    disciplines: ["BJJ", "Submission Grappling"],
    bio: "Trained under direct Gracie lineage. Runs the BTC fundamentals program with a focus on safe, technical, sustainable progression.",
  },
  {
    name: "Coach Lara",
    rank: "Certified Mat Pilates Instructor",
    disciplines: ["Pilates", "Mobility"],
    bio: "Builds the strength, control and recovery work that lets BTC's combat athletes train hard, stay healthy, and keep coming back to the mats.",
  },
];

export type Faq = { q: string; a: string };
export const faqs: Faq[] = [
  {
    q: "I've never trained a martial art before — is that okay?",
    a: "More than okay — it's most of who walks through our doors. Every discipline at BTC has a beginners' stream with dedicated coaching, and your first class is free. You'll never be thrown into the deep end.",
  },
  {
    q: "What should I wear and bring to my first class?",
    a: "Comfortable workout clothes (no jeans), a water bottle, and bare feet for taekwondo & krav maga, or athletic socks for pilates. We'll provide everything else. If you decide to continue, a uniform can be ordered through our pro-shop.",
  },
  {
    q: "Are classes split by age and experience?",
    a: "Yes. Kids' classes run in age brackets — Tigers (3–5), Juniors (6–8), Cadets (9–12) — and adult classes are streamed by level. You'll always train alongside people you can learn with, and from.",
  },
  {
    q: "How fit do I need to be?",
    a: "Whatever fitness level you're at right now is the right one to start. We've got members in their 70s training next to former state athletes. The classes meet you where you are.",
  },
  {
    q: "What if I can't make it every week?",
    a: "With 90+ classes weekly across the four halls, your membership is built to flex around your week — not the other way around. Most members average 2–3 sessions, but train as much or as little as your schedule allows.",
  },
  {
    q: "Do you offer trial classes?",
    a: "Yes. Your first class is free, no strings attached. Book online or call us on (07) 3177 4550 and we'll set you up with a session in the discipline of your choice.",
  },
];
