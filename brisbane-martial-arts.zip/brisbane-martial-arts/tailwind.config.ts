import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#0A0A0A",
          950: "#050505",
          900: "#0A0A0A",
          800: "#141414",
          700: "#1C1C1C",
          600: "#2A2A2A",
          500: "#3A3A3A",
        },
        bone: {
          DEFAULT: "#F5F1E8",
          100: "#FBF9F2",
          200: "#F5F1E8",
          300: "#E8E2D2",
          400: "#C9C2B0",
          500: "#8A8580",
        },
        ember: {
          DEFAULT: "#FF4D2E",
          50: "#FFF1ED",
          100: "#FFD9CC",
          400: "#FF7355",
          500: "#FF4D2E",
          600: "#E83817",
          700: "#B82A11",
        },
        gold: {
          DEFAULT: "#C8A55B",
          400: "#D8B96E",
          500: "#C8A55B",
          600: "#9F8443",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "Impact", "sans-serif"],
        serif: ["var(--font-serif)", "Georgia", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
      letterSpacing: {
        tightest: "-0.04em",
        tighter2: "-0.025em",
      },
      animation: {
        marquee: "marquee 40s linear infinite",
        "marquee-slow": "marquee 80s linear infinite",
        "fade-up": "fade-up 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards",
        "fade-in": "fade-in 0.6s ease forwards",
        glow: "glow 3s ease-in-out infinite",
      },
      keyframes: {
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(24px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "fade-in": {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        glow: {
          "0%, 100%": { opacity: "0.6" },
          "50%": { opacity: "1" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
